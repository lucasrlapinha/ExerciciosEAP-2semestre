﻿/*EXERCICIO 2*/

Console.WriteLine("Informe o primeiro valor (A):");
int vlA = int.Parse(Console.ReadLine());

Console.WriteLine("Informe o segundo valor (B):");
int vlB = int.Parse(Console.ReadLine());

if (vlA > vlB && vlA % vlB == 0)
{
	Console.WriteLine("São múltiplos");
}

else if(vlB > vlA && vlB % vlA == 0)
{
	Console.WriteLine("São múltiplos");
}

else
{
	Console.WriteLine("Não são multiplos");
}
