﻿/*EXERCICIO 3*/

Console.WriteLine("Informe a estimativa otimista:");
double otimista = double.Parse(Console.ReadLine());

Console.WriteLine("Informe a estimativa pessimista:");
double pessimista = double.Parse(Console.ReadLine());

Console.WriteLine("Informe a estimativa mais provável:");
double provavel = double.Parse(Console.ReadLine());

Console.WriteLine($"Otimista: {otimista}");

Console.WriteLine($"Pessimista: {pessimista}");

Console.WriteLine($"Provavel: {provavel}");

Console.WriteLine($"PERT = {(otimista + pessimista + (4 * provavel)) / 6}");



