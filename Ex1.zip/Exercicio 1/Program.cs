﻿/*EXERCICIO 1*/

Console.WriteLine("Informe o valor  de A:");
int vlA = int.Parse(Console.ReadLine());

Console.WriteLine("Informe o valor de B:");
int vlB = int.Parse(Console.ReadLine());

Console.WriteLine("Informe o valor de C:");
int vlC = int.Parse(Console.ReadLine());

Console.WriteLine($"A área do triângulo retângulo é: {vlA * vlC / 2}");

Console.WriteLine($"A área do circulo é: {3.14 * vlC * vlC}");

Console.WriteLine($"A área do trapézio é: {(vlA + vlB) * vlC /2}");

Console.WriteLine($"A área do quadrado é: {vlB * vlB}");

Console.WriteLine($"A área do retângulo é: {vlA * vlB}");

